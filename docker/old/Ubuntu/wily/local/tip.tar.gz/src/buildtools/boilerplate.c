/**
 * vim: number colorcolumn=100
 * @file
 * @brief Implements SOMETHING OR OTHER
 * @details Allows THE IMPLEMENTATION OF SOMETHING OR OTHER
 *
 * @author  Alan Robertson <alanr@unix.sh> - Copyright &copy; 2016 - Assimilation Systems Limited
 * Free support is available from the Assimilation Project community - http://assimproj.org
 * Paid support is available from Assimilation Systems Limited - http://assimilationsystems.com
 *
 * @n
 *  This file is part of the Assimilation Project.
 *  The Assimilation software is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The Assimilation software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with the Assimilation Project software.  If not, see http://www.gnu.org/licenses/
 */

-------------------------- EITHER THIS -------------------------
DEBUGDECLARATIONS
///@defgroup SOMECLASSNAME SOMECLASSNAME class
/// Class implementing SOMETHING OR OTHER
///@{
///@ingroup C_Classes
///@ingroup AssimObj

And in the "constructor"...

BINDDEBUG(Frame);
-------------------------- OR -------------------------
///@{
///@ingroup SOMECLASSNAME
/// Class implementing SOMETHING OR OTHER
-------------------------- followed by -------------------------
///@}
