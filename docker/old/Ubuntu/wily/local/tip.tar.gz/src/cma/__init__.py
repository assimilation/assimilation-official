'''Module docstring ;-) '''
