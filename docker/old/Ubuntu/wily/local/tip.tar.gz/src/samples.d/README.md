This directory contains a variety of sample programs for your reading pleasure.

We wrote them in the hopes that they'll be useful. But they're not well tested, and not necessarily even well-written. Think of them more like executable and customizable documentation ;-).

But they should give you an idea of how all these things work...
